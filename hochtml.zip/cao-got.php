<!DOCTYPE html>
<html>
<head>
<title>bán giày</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
	<header class="sticky-top">
		<div class="container">
			<div class="row">
				<div class="col-2 menu">
				<img src="img/logo2345.jpg">
				</div>
				<div class="col-2">
					
				</div>
			    <?php include './menu/menu.php'?>   




			</div>
		</div>
	</header>

	<!-- bander bắt đầu -->
	<div class="container slider-margin">
		<div class="row">
			<div class="col-12">
					<div class="slideshow-container">
		<div class="mySlides fade">
			<div class="numbertext">
			
			</div>
			
			<img src="uploads/cao-got/banner.png" style="width: 99%;">
		</div>
		</div>
		</div>
		</div>
		
<!-- bander kết thúc -->

<!-- sản phẩm -->
		 
		 <div class="row">
			<div class="col-12 title">
				<h3>Cao gót</h3>
			</div>
		</div>
		<div class="row">
			<div class="col-2th">
				<div class="card">
					<div class="image">
						<img src="uploads/cao-got/caogot2.png">
					</div>
					<div class="name">
						<p>Cao gót chính hãng</p>
						<a href="gio-hang.php" class="buy-now">Mua ngay</a>
					</div>
					<div class="price">
						<p>5.000.000 VNĐ</p>
					</div>
				</div>
			</div>
						<div class="col-2th">
				<div class="card">
					<div class="image">
                    <img src="uploads/cao-got/caogot3.png"style="width: 70%;">
					</div>
					<div class="name">
					<p>Cao gót chính hãng</p>
					<a href="gio-hang.php" class="buy-now">Mua ngay</a>
					</div>
					<div class="price">
						<p>5.000.000 VNĐ</p>>
					</div>
				</div>
			</div>
						<div class="col-2th">
				<div class="card">
					<div class="image">
                    <img src="uploads/cao-got/caogot4.png">
					</div>
					<div class="name">
					<p>Cao gót chính hãng</p>
					<a href="gio-hang.php" class="buy-now">Mua ngay</a>
					</div>
					<div class="price">
						<p>5.000.000 VNĐ</p>
					</div>
				</div>
			</div>
						<div class="col-2th">
				<div class="card">
					<div class="image">
					<img src="uploads/cao-got/caogot8.png">
					</div>
					<div class="name">
					<p>Cao gót chính hãng</p>
					<a href="gio-hang.php" class="buy-now">Mua ngay</a>
					</div>
					<div class="price">
						<p>5.000.000 VNĐ</p>
					</div>
				</div>
			</div>
						<div class="col-2th">
				<div class="card">
					<div class="image">
					<img src="uploads/caogot7.png">
					</div>
					<div class="name">
					<p>Cao gót chính hãng</p>
					<a href="gio-hang.php" class="buy-now">Mua ngay</a>
					</div>
					<div class="price">
						<p>5.000.000 VNĐ</p>
					</div>
				</div>
			</div>
						<div class="col-2th">
				<div class="card">
					<div class="image">
                    <img src="uploads/caogot8.png">
					</div>
					<div class="name">
					<p>Cao gót chính hãng</p>
					<a href="gio-hang.php" class="buy-now">Mua ngay</a>
					</div>
					<div class="price">
						<p>5.000.000 VNĐ</p>
					</div>
				</div>
			</div>
						<div class="col-2th">
				<div class="card">
					<div class="image">
                    <img src="uploads/caogot9.png">
					</div>
					<div class="name">
					<p>Cao gót chính hãng</p>
					<a href="gio-hang.php" class="buy-now">Mua ngay</a>
					</div>
					<div class="price">
						<p>5.000.000 VNĐ</p>
					</div>
				</div>
			</div>
						<div class="col-2th">
				<div class="card">
					<div class="image">
					<img src="uploads/caogot10.png">
					</div>
					<div class="name">
					<p>Cao gót chính hãng</p>
					<a href="gio-hang.php" class="buy-now">Mua ngay</a>
					</div>
					<div class="price">
						<p>5.000.000 VNĐ</p>
					</div>
				</div>
			</div>
						<div class="col-2th">
				<div class="card">
					<div class="image">
                    <img src="uploads/caogot2.png">
					</div>
					<div class="name">
					<p>Cao gót chính hãng</p>
					<a href="gio-hang.php" class="buy-now">Mua ngay</a>
					</div>
					<div class="price">
						<p>5.000.000 VNĐ</p>
					</div>
				</div>
			</div>
						<div class="col-2th">
				<div class="card">
					<div class="image">
                    <img src="uploads/caogot4.png">
					</div>
					<div class="name">
					<p>Cao gót chính hãng</p>
					<a href="gio-hang.php" class="buy-now">Mua ngay</a>
					</div>
					<div class="price">
						<p>5.000.000 VNĐ</p>
					</div>
				</div>
			</div>
		</div>
	</div> 


<!-- kết thúc sản phẩm -->
<?php include './menu/Footer.php'?> 
</body>

</html>