<div class="col-8 menu">
					<ul class ="chil">
						
						<li><a href="index.php">Trang chủ</a></li>
						<li><a href="">Sản phẩm</a>
							<ul class="menu_child">
								<li><a href="giay-quay-hau.php">Giày quay hậu</a></li>
								<li><a href="giay-the-thao.php">Giày thể thao</a></li>
								<li><a href="quy-ong.php">Giày quý ông</a></li>
								<li><a href="cao-got.php">Cao gót</a></li>
							
							</ul>
						</li>
						<li><a href="lien-he.php">Liên hệ</a></li>
						<li><a href="gioithieu.php">Giới thiệu</a></li>
					</ul>
				</div>