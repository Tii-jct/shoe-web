<!-- <footer>
		<div class="container">
			<div class="row footer">
				<div class="col-4">
				<h3>Địa chỉ</h3>
				<p>300 hà huy tập.phường Tân lợi.tp Buôn Ma Thuột</p>
				<p >- Mọi thắc mắc xin Quý khách vui lòng gọi điện thoại hoặc Email cho chúng tôi bất cứ lúc nào, 
					chúng tôi sẽ phản hồi cho Quý khách trong thời gian sớm nhất.</p>
                <p>Quý khách chưa hài lòng về chất lượng hàng hóa và phong cách phục vụ của Chi Ti, Quý khách có thể phản ánh để chúng tôi được cải thiện mình và đem đến cho Quý khách sự hài lòng nhất.</p>
              
                <div class="col-4">
               
                <p class="mb-2"><i class="fa fa-envelope text-primary mr-3"></i>timusical@gmail.com</p>
                <p class="mb-0"><i class="fa fa-phone-alt text-primary mr-3"></i>0814337854 - 0332468763</p>
</div>
            </div>
          
            

               bản đồ
                <div class="bg-light p-30 mb-30">
                    <iframe style="width: 100%; height: 250px; right:-50px;"
                    src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3892.0155073812975!2d108.07109947397446!3d12.71241072051007!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3171f78d111f3bd3%3A0x525e40b95feeb4f1!2zMzAwIEjDoCBIdXkgVOG6rXAsIFTDom4gQW4sIFRow6BuaCBwaOG7kSBCdcO0biBNYSBUaHXhu5l0LCDEkOG6r2sgTOG6r2ssIFZp4buHdCBOYW0!5e0!3m2!1svi!2s!4v1684933705919!5m2!1svi!2s"
                     width="600" height="450" style="border:0;"
                      allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                    
                </div>
                    
                </div>
            </div>
        </div>
				

		</div>
	
	</footer>     -->



    <footer>
		<div class="container">
			<div class="row footer">
				<div class="col-3">
				
					<ul class="menu_footer">
					<h3>	CHÍNH SÁCH </h3>
				
						<p2>Chính sách và quy định chung</p>
						Chính sách bán hàng và chất lượng h.hóa</p>
						Chính sách bảo mật thông tin</p>
						Chính sách Đổi - Trả hàng hóa</p>
						Chính sách vận chuyển, giao nhận h.hóa</p>
						Chính sách Bảo hành sản phẩm</p>
						Chính sách Hỗ trợ trả góp</p>
					</ul>
				</div>
				<div class="col-3">
					
				
				</div>
				<div class="col-3">
				
					<ul class="menu_footer">
				
					
					- Mọi thắc mắc xin Quý khách vui lòng gọi điện thoại hoặc Email cho chúng tôi bất cứ lúc nào, chúng tôi sẽ phản hồi cho Quý khách trong thời gian sớm nhất.</p>

– Quý khách chưa hài lòng về chất lượng hàng hóa và phong cách phục vụ của chi ti, Quý khách có thể phản ánh để chúng tôi được cải thiện mình và đem đến cho Quý khách sự hài lòng nhất.</p>

– Quý khách mua hàng trực tiếp tại Công ty và thanh toán tiền mặt hoặc Quý khách ở xa có thể mua hàng trực tuyến và chuyển khoản cho chúng tôi.</p>
WEBSITE BÁN HÀNG</p>
tigiaydep.com
                        <li><a href="">Email</a></li>
						<li><a href="">Facebook</a></li>
					</ul>
				</div>
				<div class="col-3">
				
					<ul class="menu_footer">
					<iframe style="width: 100%; height: 250px; right:-50px;"
                    src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3892.0155073812975!2d108.07109947397446!3d12.71241072051007!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3171f78d111f3bd3%3A0x525e40b95feeb4f1!2zMzAwIEjDoCBIdXkgVOG6rXAsIFTDom4gQW4sIFRow6BuaCBwaOG7kSBCdcO0biBNYSBUaHXhu5l0LCDEkOG6r2sgTOG6r2ssIFZp4buHdCBOYW0!5e0!3m2!1svi!2s!4v1684933705919!5m2!1svi!2s"
                     width="600" height="450" style="border:0;"
                      allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                    
					</ul>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-12 copy_right">
				
			</div>
		</div>
	</footer>