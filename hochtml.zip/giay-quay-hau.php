<!DOCTYPE html>
<html>
<head>
<title>bán giày</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
	<header class="sticky-top">
		<div class="container">
			<div class="row">
				<div class="col-2 menu">
				<img src="img/logo2345.jpg">
				</div>
				<div class="col-2">
					
				</div>
			    <?php include './menu/menu.php'?>   




			</div>
		</div>
	</header>

	<!-- bander bắt đầu -->
	<div class="container slider-margin">
		<div class="row">
			<div class="col-12">
					<div class="slideshow-container">
		<div class="mySlides fade">
			<div class="numbertext">
			
			</div>
			
			<img src="uploads/banderdep.png" style="width: 99%;">
		</div>
		</div>
		</div>
		</div>
		
<!-- bander kết thúc -->

<!-- sản phẩm -->
		 
		 <div class="row">
			<div class="col-12 title">
				<h3>Giày quay hậu</h3>
			</div>
		</div>
		<div class="row">
			<div class="col-2th">
				<div class="card">
					<div class="image">
						<img src="uploads/giay/giay4.png">
					</div>
					<div class="name">
						<p> GIÀY QUAY HẬU ĐẸP.CHÍNH HÃNG</p>
						<a href="gio-hang.php" class="buy-now">Mua ngay</a>
					</div>
					<div class="price">
						<p>5.000.000 VNĐ</p>
					</div>
				</div>
			</div>
						<div class="col-2th">
				<div class="card">
					<div class="image">
						<img src="uploads/giay/giaymyn2.png">
					</div>
					<div class="name">
					<p> GIÀY QUAY HẬU ĐẸP.CHÍNH HÃNG</p>
					<a href="gio-hang.php" class="buy-now">Mua ngay</a>
					</div>
					<div class="price">
						<p>5.000.000 VNĐ</p>
					</div>
				</div>
			</div>
						<div class="col-2th">
				<div class="card">
					<div class="image">
					<img src="uploads/giay/giaymyn.png">
					</div>
					<div class="name">
					<p> GIÀY QUAY HẬU ĐẸP.CHÍNH HÃNG</p>
					<a href="gio-hang.php" class="buy-now">Mua ngay</a>
					</div>
					<div class="price">
						<p>5.000.000 VNĐ</p>
					</div>
				</div>
			</div>
						<div class="col-2th">
				<div class="card">
					<div class="image">
					<img src="uploads/giay/giay10.png">
					</div>
					<div class="name">
					<p> GIÀY QUAY HẬU ĐẸP.CHÍNH HÃNG</p>
					<a href="gio-hang.php" class="buy-now">Mua ngay</a>
					</div>
					<div class="price">
						<p>5.000.000 VNĐ</p>
					</div>
				</div>
			</div>
						<div class="col-2th">
				<div class="card">
					<div class="image">
					<img src="uploads/giay/giay11.png">
					</div>
					<div class="name">
					<p> GIÀY QUAY HẬU ĐẸP.CHÍNH HÃNG</p>
					<a href="gio-hang.php" class="buy-now">Mua ngay</a>
					</div>
					<div class="price">
						<p>5.000.000 VNĐ</p>
					</div>
				</div>
			</div>
						<div class="col-2th">
				<div class="card">
					<div class="image">
					<img src="uploads/giay/giay4.png">
					</div>
					<div class="name">
					<p> GIÀY QUAY HẬU ĐẸP.CHÍNH HÃNG</p>
					<a href="gio-hang.php" class="buy-now">Mua ngay</a>
					</div>
					<div class="price">
						<p>5.000.000 VNĐ</p>
					</div>
				</div>
			</div>
						<div class="col-2th">
				<div class="card">
					<div class="image">
					<img src="uploads/giay/giay5.png">
					</div>
					<div class="name">
					<p> GIÀY QUAY HẬU ĐẸP.CHÍNH HÃNG</p>
					<a href="gio-hang.php" class="buy-now">Mua ngay</a>
					</div>
					<div class="price">
						<p>5.000.000 VNĐ</p>
					</div>
				</div>
			</div>
						<div class="col-2th">
				<div class="card">
					<div class="image">
					<img src="uploads/giay/giay6.png">
					</div>
					<div class="name">
					<p> GIÀY QUAY HẬU ĐẸP.CHÍNH HÃNG</p>
					<a href="gio-hang.php" class="buy-now">Mua ngay</a>
					</div>
					<div class="price">
						<p>5.000.000 VNĐ</p>
					</div>
				</div>
			</div>
						<div class="col-2th">
				<div class="card">
					<div class="image">
					<img src="uploads/giay/giay7.png">
					</div>
					<div class="name">
					<p> GIÀY QUAY HẬU ĐẸP.CHÍNH HÃNG</p>
					<a href="gio-hang.php" class="buy-now">Mua ngay</a>
					</div>
					<div class="price">
						<p>5.000.000 VNĐ</p>
					</div>
				</div>
			</div>
						<div class="col-2th">
				<div class="card">
					<div class="image">
					<img src="uploads/giay/giay10.png">
					</div>
					<div class="name">
					<p> GIÀY QUAY HẬU ĐẸP.CHÍNH HÃNG</p>
					<a href="gio-hang.php" class="buy-now">Mua ngay</a>
					</div>
					<div class="price">
						<p>5.000.000 VNĐ</p>
					</div>
				</div>
			</div>
		</div>
	</div> 


<!-- kết thúc sản phẩm -->
<?php include './menu/Footer.php'?> 
</body>

</html>