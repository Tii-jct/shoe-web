

    <!DOCTYPE html>
<html>
<head>
<title>bán giày</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
	<header class="sticky-top">
		<div class="container">
			<div class="row">
				<div class="col-2 menu">
				<img src="img/logo2345.jpg">
				</div>
				<div class="col-2">
					
				</div>
                   
				<!-- menu -->
				<?php include './menu/menu.php'?>  
				
			</div>
		</div>
	</header>

<div class="container-fluid">
        <h1>GiÀY DÉP ĐẠI LÝ CHÍNH THỨC CỦA GUCCI</h1>
       GUCCI là tập đoàn lớn có xuất xứ từ Ý. Đây cũng là thương hiệu uy tín trên thế giới và rất được tin dùng tại Việt Nam.Được người yêu thời trang trên thế giới đón nhận và đánh giá rất cao.</p>
        
<img src="img/chungnhan.png" style="width: 50%;">
<p2>Sau nhiều năm phấn đấu và nỗ lực, năm 2013 là năm đánh dấu mốc quan trọng trong hành trình vươn ra thị trường cũng như trên mọi nẻo đường mà sản phẩm của Chi Ti đi qua và ở lại.

Với sự đổi mới không ngừng để xây dựng  thương hiệu uy tín và là địa chỉ tin cậy của người thời trang.
Với sự thành công trong việc phát triển chuỗi đại lý
Với những cố gắng hết mình của tập thể lãnh đạo và nhân viên, giày dép Chi Ti luôn đáp ứng nhu cầu của khách hàng một cách tốt nhất và nhanh nhất. 

Chúng tôi vô cùng hạnh phúc và cảm ơn vì những nỗ lực đó đã được công nhận: giày dép Chi Ti trở thành đại lý chính thức được Công ty Yamaha Việt Nam tin tưởng trao quyền ủy nhiệm phân phối các sản phẩm giày  và dịch vụ chính hãng. </p>
<img src="img/khaitruong.jpg" style="width: 50%;">
<h1>
Khi mua giày tại Chi Ti bạn sẽ được hưởng những chính sách sau:
</h1>

 <p2>+ Chúng tôi mở cửa vào tất cả các ngày trong tuần (kể cả thứ 7 và chủ nhật).</p>
 <p2>+ Sẵn sàng tư vấn,  thay dây hay căn chỉnh giày dép cho các bạn, kể cả khi bạn mua đàn nơi khác.</p>
 <p2>+ Công ty có Shoroom tại Hà Nội và tp. HCM nên dù bạn ở đâu, bạn vẫn có thể mua hàng được</p>
 <p2>+ Công ty có tổ chức chương trình khuyến mãi và tặng đàn Guitar miễn phí theo tháng hoặc vào những ngày lễ lớn. 
    Vì thế, hãy theo dõi chúng tôi trên facebook để có cơ hội nhận đàn Guitar miễn phí nhé. </p>
 <p2>+ Chiết khấu đặc biệt cho cửa hàng đại lý bán và khách hàng mua số lượng lớn. Chương trình giảm giá 5 - 10 %, tặng phụ kiện, tặng gói bảo hành cho tất cả các sản phẩm được lên lịch thường xuyên tại Chi Ti.</p>
 <p2>+ Chế độ bảo hành theo quy định của nhà sẳn xuất
                    </p>
   

<?php include './menu/Footer.php'?>
	
</body>

</html>       