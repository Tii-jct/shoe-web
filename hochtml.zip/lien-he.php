

    <!DOCTYPE html>
<html>
<head>
<title>bán giày</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
	<header class="sticky-top">
		<div class="container">
			<div class="row">
				<div class="col-2 menu">
				<img src="img/logo2345.jpg">
				</div>
				<div class="col-2">
					
				</div>
                   
				<!-- menu -->
				<?php include './menu/menu.php'?>  
				
			</div>
		</div>
	</header>
	<div class="container">
			<div class="row footer">
				<div class="col-3">
				
					<ul class="menu_footer">
					<h3>	Cám ơn Quý khách đã liên hệ tới shop Chi Ti 
Chúc Quý khách luôn vui vẻ và thành công!</h3>
				   
						
					</ul>
				</div>
				<div class="col-3">
									
				</div>
				<div class="col-3">
				
					<ul class="menu_footer">
				
					
					
                        <li><a href="">Email</a></li>
						<li><a href="">Facebook</a></li>
						<li><a href="">SĐT:0332467890 </a></li>
					</ul>
				</div>
				<div class="col-3">
				
					<ul class="menu_footer">
					<iframe style="width: 100%; height: 250px; right:-50px;"
                    src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3892.0155073812975!2d108.07109947397446!3d12.71241072051007!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3171f78d111f3bd3%3A0x525e40b95feeb4f1!2zMzAwIEjDoCBIdXkgVOG6rXAsIFTDom4gQW4sIFRow6BuaCBwaOG7kSBCdcO0biBNYSBUaHXhu5l0LCDEkOG6r2sgTOG6r2ssIFZp4buHdCBOYW0!5e0!3m2!1svi!2s!4v1684933705919!5m2!1svi!2s"
                     width="600" height="450" style="border:0;"
                      allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                    
					</ul>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-12 copy_right">
				
			</div>
		</div>

<?php include './menu/Footer.php'?>
	
</body>

</html>       